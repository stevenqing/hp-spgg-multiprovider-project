# PACT AAAI-27 Anonymous Paper Package

This archive contains the RQ-restructured anonymous paper, its full technical supplement, the official AAAI-27 style files, bibliography, and exactly the referenced figure assets.

## Canonical PDFs

- `PACT_AAAI27.pdf`: 11-page submission artifact (main text + references + checklist; no technical appendix).
- `main.pdf`: 29-page full review bundle including the technical supplement and checklist.

Figure 3 is the analytic HP-SPGG RQ3 component ladder. Figure 5 is the two-panel iterated-Concordia RQ2/RQ3 diagnostic. Figure 6 reports the final MaaSSim grid with lambda in {0, 0.5, 1}.

## Build

With MiKTeX/TeX Live and BibTeX installed, build the full bundle from this directory:

```text
pdflatex -interaction=nonstopmode main.tex
bibtex main
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main.tex
```

The package is anonymous and intentionally omits logs, auxiliary files, experiment data, provider configuration, historical figure drafts, and local paths. File hashes are recorded in `SHA256SUMS.txt` and `MANIFEST.csv`.
