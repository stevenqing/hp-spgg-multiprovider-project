# Copyright 2023 DeepMind Technologies Limited.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""A modular entity agent using the new component system."""

from collections.abc import Mapping
from concurrent import futures
import functools
import threading
import traceback
import types
from typing import cast, override

from absl import logging
from concordia.typing import entity
from concordia.typing import entity_component
from concordia.utils import concurrency

# TODO: b/313715068 - remove disable once pytype bug is fixed.
# pytype: disable=override-error


class EntityAgent(entity_component.EntityWithComponents):
  """An agent that has its functionality defined by components.

  The agent has a set of components that define its functionality. The agent
  must have at least an ActComponent and an ObserveComponent. The agent will
  call the ActComponent's `act` method when it needs to act, and the
  ObservationComponent's `observe` method when they need to process an
  observation.
  """

  def __init__(
      self,
      agent_name: str,
      act_component: entity_component.ActingComponent,
      context_components: Mapping[str, entity_component.ContextComponent] = (
          types.MappingProxyType({})
      ),
  ):
    """Initializes the agent.

    The passed components will be owned by this entity agent (i.e. their
    `set_entity` method will be called with this entity as the argument).

    Args:
      agent_name: The name of the agent.
      act_component: The component that will be used to act.
      context_components: The ContextComponents that will be used by the agent.
    """
    super().__init__()
    self._agent_name = agent_name
    self._control_lock = threading.Lock()
    self._phase_lock = threading.Lock()
    self._phase = entity_component.Phase.READY
    self._capture_key_by_thread: dict[int, str] = {}
    self._active_capture_key: str = agent_name

    self._act_component = act_component
    self._act_component.set_entity(self)

    self._context_components = dict(context_components)
    for component in self._context_components.values():
      component.set_entity(self)

  @override
  @functools.cached_property
  def name(self) -> str:
    return self._agent_name

  @override
  def get_phase(self) -> entity_component.Phase:
    with self._phase_lock:
      return self._phase

  def _set_phase(self, phase: entity_component.Phase) -> None:
    with self._phase_lock:
      self._phase.check_successor(phase)
      self._phase = phase

  @override
  def get_component(
      self,
      name: str,
      *,
      type_: type[entity_component.ComponentT] = entity_component.BaseComponent,
  ) -> entity_component.ComponentT:
    component = self._context_components[name]
    return cast(entity_component.ComponentT, component)

  def get_act_component(self) -> entity_component.ActingComponent:
    return self._act_component

  def get_all_context_components(
      self,
  ) -> Mapping[str, entity_component.ContextComponent]:
    return types.MappingProxyType(self._context_components)

  def _parallel_call_(
      self,
      method_name: str,
      *args,
      executor: futures.ThreadPoolExecutor | None = None,
  ) -> entity_component.ComponentContextMapping:
    """Calls the named method in parallel on all components.

    If a component instance is registered under multiple names, its method
    will only be called once. The result of that call will be mapped to all
    names under which it was registered.

    All calls will be issued with the same payloads.

    Args:
      method_name: The name of the method to call.
      *args: The arguments to pass to the method.
      executor: An optional existing ThreadPoolExecutor to use.

    Returns:
      A ComponentsContext, that is, a mapping of component name to the result of
      the method call.
    """
    # 1. Identify unique component instances.
    unique_components = list(set(self._context_components.values()))

    # 2. Create and execute tasks for each unique component instance once.
    tasks_for_unique = {
        str(id(component)): functools.partial(
            getattr(component, method_name), *args
        )
        for component in unique_components
    }
    results_by_component_id = concurrency.run_tasks(
        tasks_for_unique, executor=executor
    )

    # 3. Construct the final results dictionary.
    final_results: dict[str, str] = {}
    for name, component in self._context_components.items():
      final_results[name] = results_by_component_id[str(id(component))]

    return types.MappingProxyType(final_results)

  @override
  def act(
      self, action_spec: entity.ActionSpec = entity.DEFAULT_ACTION_SPEC
  ) -> str:
    with self._control_lock:
      # Activate per-thread capture key so log data from this act() call
      # is routed to the correct entity thread's capture context.
      key_override = self._capture_key_by_thread.get(
          threading.current_thread().ident
      )
      if key_override is not None:
        self._active_capture_key = key_override
      try:
        self._set_phase(entity_component.Phase.PRE_ACT)
        contexts = self._parallel_call_('pre_act', action_spec)
        action_attempt = self._act_component.get_action_attempt(
            contexts, action_spec
        )

        self._set_phase(entity_component.Phase.POST_ACT)
        self._parallel_call_('post_act', action_attempt)

        self._set_phase(entity_component.Phase.UPDATE)
        self._parallel_call_('update')

        self._set_phase(entity_component.Phase.READY)

        return action_attempt
      except Exception:
        # Ensure correct error handling in the case of multiple threads
        # using the same entity by setting the phase to ready before raising.
        self.set_phase(entity_component.Phase.READY)
        raise
      finally:
        self._active_capture_key = self._agent_name

  @override
  def observe(self, observation: str) -> None:
    with self._control_lock:
      # Activate per-thread capture key (same as act()).
      key_override = self._capture_key_by_thread.get(
          threading.current_thread().ident
      )
      if key_override is not None:
        self._active_capture_key = key_override
      try:
        self._set_phase(entity_component.Phase.PRE_OBSERVE)
        self._parallel_call_('pre_observe', observation)

        self._set_phase(entity_component.Phase.POST_OBSERVE)
        self._parallel_call_('post_observe')

        self._set_phase(entity_component.Phase.UPDATE)
        self._parallel_call_('update')

        self._set_phase(entity_component.Phase.READY)
      except Exception:
        # Ensure correct error handling in the case of multiple threads
        # using the same entity by setting the phase to ready before raising.
        self.set_phase(entity_component.Phase.READY)
        raise
      finally:
        self._active_capture_key = self._agent_name

  def set_state(
      self, entity_components_state: entity_component.EntityState
  ) -> None:
    """Sets the state of the agent."""

    # Restore context components
    context_components_state = entity_components_state.get(
        'context_components', {}
    )
    for component_name, component in self._context_components.items():
      if component_name in context_components_state:
        try:
          component.set_state(context_components_state[component_name])
        except Exception:  # pylint: disable=broad-exception-caught
          logging.error(
              'Error setting state for component %s: %s',
              component_name, traceback.format_exc()
          )

    # Restore act component
    act_state = entity_components_state.get('act_component')
    if act_state:
      try:
        self._act_component.set_state(act_state)
      except Exception:  # pylint: disable=broad-exception-caught
        logging.error(
            'Error setting state for act component: %s', traceback.format_exc()
        )

  def get_state(self) -> entity_component.EntityState:
    """Returns the state of the agent as a dictionary."""
    return {
        'act_component': self._act_component.get_state(),
        'context_components': {
            component_name: component.get_state()
            for component_name, component in self._context_components.items()
        },
    }

  def set_phase(self, phase: entity_component.Phase) -> None:
    with self._phase_lock:
      self._phase = phase

