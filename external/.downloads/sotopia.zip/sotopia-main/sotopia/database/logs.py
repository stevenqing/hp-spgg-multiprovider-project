import sys
from typing import TYPE_CHECKING

if sys.version_info >= (3, 11):
    from typing import Self
else:
    from typing_extensions import Self

from typing import Literal

from pydantic import BaseModel, model_validator
from redis_om import JsonModel
from redis_om.model.model import Field

from sotopia.database.persistent_profile import AgentProfile

from .base_models import patch_model_for_local_storage
from .storage_backend import is_local_backend


class BaseNonStreamingSimulationStatus(BaseModel):
    pk: str | None = Field(default_factory=lambda: "")
    episode_pk: str = Field(index=True)
    status: Literal["Started", "Error", "Completed"]


if TYPE_CHECKING:
    # For type checking, always assume Redis backend to get proper method signatures
    class NonStreamingSimulationStatus(BaseNonStreamingSimulationStatus, JsonModel):
        pass
elif is_local_backend():

    class NonStreamingSimulationStatus(BaseNonStreamingSimulationStatus):
        pass
else:

    class NonStreamingSimulationStatus(BaseNonStreamingSimulationStatus, JsonModel):  # type: ignore[no-redef]
        pass


class BaseEpisodeLog(BaseModel):
    # Note that we did not validate the following constraints:
    # 1. The number of turns in messages and rewards should be the same or off by 1
    # 2. The agents in the messages are the same as the agetns

    pk: str | None = Field(default_factory=lambda: "")
    environment: str = Field(index=True)
    agents: list[str] = Field(index=True)
    tag: str | None = Field(index=True, default="")
    models: list[str] | None = Field(index=True, default=[])
    agent_classes: list[str] | None = Field(index=True, default=[])
    messages: list[list[tuple[str, str, str]]]  # Messages arranged by turn
    reasoning: str = Field(default="")
    rewards: list[tuple[float, dict[str, float]] | float]  # Rewards arranged by turn
    rewards_prompt: str = Field(default="")

    @model_validator(mode="after")
    def agent_number_message_number_reward_number_turn_number_match(
        self,
    ) -> Self:
        agent_number = len(self.agents)

        assert (
            len(self.rewards) == agent_number
        ), f"Number of agents in rewards {len(self.rewards)} and agents {agent_number} do not match"
        return self

    def render_for_humans(self) -> tuple[list[AgentProfile], list[str]]:
        """Generate a human readable version of the episode log.

        Returns:
            A tuple of (a list of agent_profiles, a list of str): The agent profiles, and the messages and rewards in each turn.
        """

        agent_profiles = [AgentProfile.get(pk=uuid_str) for uuid_str in self.agents]
        messages_and_rewards = []
        for idx, turn in enumerate(self.messages):
            messages_in_this_turn = []
            if idx == 0:
                assert (
                    len(turn) >= 2
                ), "The first turn should have at least environemnt messages"
                messages_in_this_turn.append(
                    f"{turn[0][1]}'s perspective (i.e., what {turn[0][1]} knows before the episode starts): {turn[0][2]}"
                )
                messages_in_this_turn.append(
                    f"{turn[1][1]}'s perspective (i.e., what {turn[1][1]} knows before the episode starts): {turn[1][2]}"
                )
            for sender, receiver, message in turn:
                if receiver == "Environment":
                    if sender != "Environment":
                        if "did nothing" in message:
                            continue
                        else:
                            if "said:" in message:
                                messages_in_this_turn.append(f"{sender} {message}")
                            else:
                                messages_in_this_turn.append(f"{sender}: {message}")
                    else:
                        messages_in_this_turn.append(message)
            messages_and_rewards.append("\n".join(messages_in_this_turn))
        messages_and_rewards.append(f"The reasoning is:\n{self.reasoning}")
        messages_and_rewards.append(
            f"The rewards are:\nAgent 1: {self.rewards[0]}\nAgent 2: {self.rewards[1]}"
        )
        return agent_profiles, messages_and_rewards


if TYPE_CHECKING:
    # For type checking, always assume Redis backend to get proper method signatures
    class EpisodeLog(BaseEpisodeLog, JsonModel):
        pass
elif is_local_backend():

    class EpisodeLog(BaseEpisodeLog):
        pass
else:

    class EpisodeLog(BaseEpisodeLog, JsonModel):  # type: ignore[no-redef]
        pass


class BaseAnnotationForEpisode(BaseModel):
    pk: str | None = Field(default_factory=lambda: "")
    episode: str = Field(index=True, description="the pk id of episode log")
    annotator_id: str = Field(index=True, full_text_search=True)
    rewards: list[tuple[float, dict[str, float]] | float]
    reasoning: str


if TYPE_CHECKING:
    # For type checking, always assume Redis backend to get proper method signatures
    class AnnotationForEpisode(BaseAnnotationForEpisode, JsonModel):
        pass
elif is_local_backend():

    class AnnotationForEpisode(BaseAnnotationForEpisode):
        pass
else:

    class AnnotationForEpisode(BaseAnnotationForEpisode, JsonModel):  # type: ignore[no-redef]
        pass


# Patch model classes for local storage support
NonStreamingSimulationStatus = patch_model_for_local_storage(  # type: ignore[misc]
    NonStreamingSimulationStatus
)
EpisodeLog = patch_model_for_local_storage(EpisodeLog)  # type: ignore[misc]
AnnotationForEpisode = patch_model_for_local_storage(AnnotationForEpisode)  # type: ignore[misc]
